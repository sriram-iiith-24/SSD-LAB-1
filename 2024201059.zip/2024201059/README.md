steps to execute 2024201059_q1.sh

1. Give execute permissions to user using "chmod +x 2024201059_q1.sh".
2. Run the executable using "./2024201059_q1.sh"


steps to execute 2024201059_q2.sh

1. Give execute permissions to user "chmod +x 2024201059_q2.sh".
2. Run the executable using "./2024201059_q2.sh"


